from vi import Agent, Config, Simulation


class MyAgent(Agent):
  def update(self):
         in_proximity = self.in_proximity_accuracy().count()

         if in_proximity >= 1:
             self.change_image(1)
         else:
             self.change_image(0)


(
    Simulation(Config(radius=15))
    .batch_spawn_agents(
        500,
        MyAgent,  # 👈 use our own MyAgent class
        images=[
            "examples/images/white.png",
            "examples/images/red.png",
        ],
    )
    .run()
)

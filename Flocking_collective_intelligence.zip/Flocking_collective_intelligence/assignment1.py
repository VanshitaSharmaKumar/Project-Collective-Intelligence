from distutils.command.config import config
from enum import Enum, auto
from turtle import position

import pygame as pg
from pygame.math import Vector2
from vi import Agent, Simulation, Window
from vi.config import Config, dataclass, deserialize
from pygame.gfxdraw import circle
from math import exp


@deserialize
@dataclass
class AggregationConfig(Config):
    timer: int = 5  # ticks
    probability_join: float = 0.5
    probability_leave: float = 0.2

    def weights(self) -> tuple[int, float, float]:
        return (self.timer, self.probability_join, self.probability_leave)


class Cockroach(Agent):
    config: AggregationConfig
    max_velocity: int = 1
    state: int = 0  # 0 - wandering, 1 - joining , 2 - still, 3 - leave
    timer: int = AggregationConfig.timer

    def join_probability(self):
        p_stay = 0.03 + 0.48 * (1 - exp(-3 * self.in_proximity_accuracy().count()))
        return p_stay

    def leave_proability(self):
        p_leave = exp(-0.5 * self.in_proximity_accuracy().count())
        return p_leave

    def movement(self):
        self.there_is_no_escape()
        prng = self.shared.prng_move

        # two next lines to bump from each other (Sprites)
        # self._obstacles.empty()
        # self._obstacles.add(self.in_proximity_accuracy().without_distance())
        obstacle_hit = pg.sprite.spritecollideany(self, self._obstacles, pg.sprite.collide_mask)  # type: ignore
        collision = bool(obstacle_hit)

        if collision and not self._still_stuck:
            self.move.rotate_ip(180)
            self._still_stuck = True

        if not collision:
            self._still_stuck = False

            in_proximity = list(self.in_proximity_accuracy())

            if len(in_proximity) == 0:
                screen = pg.display.get_surface()
                x, y = self.center
                radius = self.config.radius
                circle(screen, x, y, radius, (0, 191, 255))

        should_change_angle = prng.random()
        deg = prng.uniform(-10, 10)

        if not collision and not self._still_stuck and 0.25 > should_change_angle:
            self.move.rotate_ip(deg)

        self.pos += self.move

    def change_position(self):
        if self.state == 0:
            print("state")
            self.movement()
            if self.on_site():
                if self.join_probability() > self.config.probability_join:
                    self.state = 1

        elif self.state == 1:  # joining
            self.timer = self.config.timer
            while self.timer > 0:
                self.timer -= 1
                self.movement()
            self.state += 1

        elif self.state == 2:  # stay
            self.timer = self.config.timer
            if self.move != [0, 0] and self.on_site():
                self.freeze_movement()
                while self.timer > 0:
                    self.timer -= 1
                self.state += 1
            elif self.move == [0, 0] and self.on_site():
                self.state += 1
            else:
                self.state = 0

        elif self.state == 3:  # leaving
            print(self.leave_proability())
            if self.leave_proability() > self.config.probability_leave:
                self.timer = self.config.timer
                while self.timer > 0:
                    self.continue_movement()
                    self.move.rotate_ip(180)
                    self.movement()
                    self.timer -= 1
                self.state = 0
            else:
                self.state = 2


class Selection(Enum):
    TIMER = auto()
    PROBABILITY_JOIN = auto()
    PROBABILITY_LEAVE = auto()


class AggregationLive(Simulation):
    selection: Selection = Selection.TIMER
    config: AggregationConfig

    def handle_event(self, by: float):
        if self.selection == Selection.TIMER:
            self.config.timer += by * 100
        elif self.selection == Selection.PROBABILITY_JOIN:
            self.config.probability_join += by
        elif self.selection == Selection.PROBABILITY_LEAVE:
            self.config.probability_leave += by

    def before_update(self):
        super().before_update()

        for event in pg.event.get():
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_UP:
                    self.handle_event(by=0.01)
                elif event.key == pg.K_DOWN:
                    self.handle_event(by=-0.01)
                elif event.key == pg.K_1:
                    self.selection = Selection.TIMER
                elif event.key == pg.K_2:
                    self.selection = Selection.PROBABILITY_JOIN
                elif event.key == pg.K_3:
                    self.selection = Selection.PROBABILITY_LEAVE

        t, j, l = self.config.weights()
        pg.display.set_caption(f"Timer: {t:.0f} - P_join: {j:.2f} - P_leave: {l:.2f}")


window_size = 500
(
    AggregationLive(
        AggregationConfig(
            movement_speed=10,
            radius=30,
            seed=12345,
            window=Window.square(window_size),
        )
    )
    # .spawn_obstacle("images/bubble-full.png", window_size / 2, window_size / 2)
    .spawn_site("images/site100x100.png", window_size / 5, window_size / 2)
    .spawn_site("images/site100x100.png", window_size / 5 * 4, window_size / 2)
    .spawn_obstacle("images/bubble-full500x500.png", window_size / 2, window_size / 2)
    .batch_spawn_agents(100, Cockroach, images=["images/cockroach.png"])
    .run()
)

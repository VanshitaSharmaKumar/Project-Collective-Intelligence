from distutils.command.config import config
from enum import Enum, auto
from turtle import position

import pygame as pg
from pygame.math import Vector2
from vi import Agent, Simulation, Window
from vi.config import Config, dataclass, deserialize
from pygame.gfxdraw import circle


@deserialize
@dataclass
class FlockingConfig(Config):
    alignment_weight: float = 0.5
    cohesion_weight: float = 0.5
    separation_weight: float = 0.5

    delta_time: float = 3

    mass: int = 20

    def weights(self) -> tuple[float, float, float]:
        return (self.alignment_weight, self.cohesion_weight, self.separation_weight)


class Bird(Agent):
    config: FlockingConfig
    max_velocity: int = 1

    def alignment(self, in_proximity):

        velocities_0 = sum(agent.move[0] for agent, _ in in_proximity)
        velocities_1 = sum(agent.move[1] for agent, _ in in_proximity)
        avg_velocities_0 = (
            velocities_0 / len(in_proximity) if len(in_proximity) > 0 else 0
        )
        avg_velocities_1 = (
            velocities_1 / len(in_proximity) if len(in_proximity) > 0 else 0
        )
        avg_velocities = Vector2(avg_velocities_0, avg_velocities_1)
        return avg_velocities - self.move

    def separation(self, in_proximity):
        position_0 = sum(self.pos[0] - agent.pos[0] for agent, _ in in_proximity)
        position_1 = sum(self.pos[1] - agent.pos[1] for agent, _ in in_proximity)
        avg_position_0 = position_0 / len(in_proximity) if len(in_proximity) > 0 else 0
        avg_position_1 = position_1 / len(in_proximity) if len(in_proximity) > 0 else 0

        return Vector2(avg_position_0, avg_position_1)

    def cohesion(self, in_proximity):
        position_0 = sum(agent.pos[0] for agent, _ in in_proximity)
        position_1 = sum(agent.pos[1] for agent, _ in in_proximity)
        avg_position_0 = position_0 / len(in_proximity) if len(in_proximity) > 0 else 0
        avg_position_1 = position_1 / len(in_proximity) if len(in_proximity) > 0 else 0
        fc = Vector2(avg_position_0, avg_position_1) - self.pos
        return fc - self.move

    def change_position(self):
        self.there_is_no_escape()

        # Obstacle Avoidance
        obstacle_hit = pg.sprite.spritecollideany(self, self._obstacles, pg.sprite.collide_mask)  # type: ignore
        collision = bool(obstacle_hit)

        # Reverse direction when colliding with an obstacle.
        if collision and not self._still_stuck:
            self.move.rotate_ip(180)
            self._still_stuck = True

        if not collision:
            self._still_stuck = False

            in_proximity = list(self.in_proximity_accuracy())

            if len(in_proximity) == 0:
                screen = pg.display.get_surface()
                x, y = self.center
                radius = self.config.radius
                circle(screen, x, y, radius, (255, 255, 255))
            else:
                a_weight, s_weight, c_weight = self.config.weights()
                a = self.alignment(in_proximity) * a_weight
                s = self.separation(in_proximity) * s_weight
                c = self.cohesion(in_proximity) * c_weight

                f_total = (a + s + c) / self.config.mass
                new_move = self.move + f_total

                if new_move.length() > self.max_velocity:
                    new_move = new_move.normalize()

                elif new_move.length() < self.max_velocity:
                    new_move = new_move.normalize() * self.max_velocity

                self.move = new_move

        self.pos += self.move


class Selection(Enum):
    ALIGNMENT = auto()
    COHESION = auto()
    SEPARATION = auto()


class FlockingLive(Simulation):
    selection: Selection = Selection.ALIGNMENT
    config: FlockingConfig

    def handle_event(self, by: float):
        if self.selection == Selection.ALIGNMENT:
            self.config.alignment_weight += by
        elif self.selection == Selection.COHESION:
            self.config.cohesion_weight += by
        elif self.selection == Selection.SEPARATION:
            self.config.separation_weight += by

    def before_update(self):
        super().before_update()

        for event in pg.event.get():
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_UP:
                    self.handle_event(by=0.1)
                elif event.key == pg.K_DOWN:
                    self.handle_event(by=-0.1)
                elif event.key == pg.K_1:
                    self.selection = Selection.ALIGNMENT
                elif event.key == pg.K_2:
                    self.selection = Selection.COHESION
                elif event.key == pg.K_3:
                    self.selection = Selection.SEPARATION

        a, c, s = self.config.weights()
        pg.display.set_caption(f"A: {a:.1f} - C: {c:.1f} - S: {s:.1f}")
        # print(f"A: {a:.1f} - C: {c:.1f} - S: {s:.1f}")


window_size = 500
(
    FlockingLive(
        FlockingConfig(
            image_rotation=True,
            movement_speed=1,
            radius=50,
            seed=12345,
            window=Window.square(window_size),
        )
    )
    .spawn_obstacle("images/bubble-full.png", window_size / 2, window_size / 2)
    .batch_spawn_agents(100, Bird, images=["images/bird.png"])
    # .spawn_obstacle("examples/images/rect.png", x= 250,y =  250)
    .run()
)
